from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

import asyncio
import os
import logging
import uuid
from contextlib import suppress
from datetime import datetime, timezone, timedelta
from typing import Literal, Optional

import bcrypt
import jwt
from bson import ObjectId
from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Depends, Query
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, EmailStr
from pymongo import ASCENDING, DESCENDING, IndexModel
from starlette.middleware.cors import CORSMiddleware

from emailer import send_email, lead_email_html, chat_email_html

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

client = AsyncIOMotorClient(os.environ['MONGO_URL'])
db = client[os.environ['DB_NAME']]
JWT_ALGORITHM = "HS256"

INDEXES: dict[str, list[IndexModel]] = {
    "users": [IndexModel([("email", ASCENDING)], name="email", unique=True)],
    "login_attempts": [IndexModel([("identifier", ASCENDING)], name="identifier")],
    "leads": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("created_at", DESCENDING)], name="created_desc"),
        IndexModel([("brand", ASCENDING)], name="brand"),
        IndexModel([("status", ASCENDING)], name="status"),
    ],
}


async def ensure_indexes() -> None:
    for collection, models in INDEXES.items():
        for model in models:
            try:
                await db[collection].create_indexes([model])
            except Exception as exc:
                logger.error("ensure_indexes(%s.%s): %s", collection, model.document["name"], exc)


app = FastAPI()
api = APIRouter(prefix="/api")

Status = Literal["new", "contacted", "scheduled", "resolved"]


class LeadIn(BaseModel):
    name: Optional[str] = Field(default="", max_length=80)
    customer_type: Literal["home", "business"] = "home"
    company: Optional[str] = Field(default="", max_length=120)
    phone: str = Field(min_length=7, max_length=25)
    email: Optional[EmailStr] = None
    brand: Literal["HP", "Canon", "Epson", "Brother", "Other"]
    model: Optional[str] = Field(default="", max_length=80)
    issue_category: str = Field(default="Quick enquiry", min_length=2, max_length=60)
    location: Optional[str] = Field(default="", max_length=160)
    visit_type: Optional[Literal["remote", "on-site", "drop-off"]] = "on-site"
    preferred_time: Optional[str] = Field(default="", max_length=80)
    description: Optional[str] = Field(default="", max_length=1500)
    source_page: Optional[str] = Field(default="", max_length=60)
    company_website: Optional[str] = ""


class Lead(BaseModel):
    id: str
    name: str = ""
    customer_type: str = "home"
    company: str = ""
    phone: str
    email: Optional[str] = None
    brand: str
    model: str = ""
    issue_category: str
    location: str = ""
    visit_type: str = "on-site"
    preferred_time: str = ""
    description: str = ""
    source_page: str = ""
    status: str = "new"
    email_sent: bool = False
    created_at: str


class ChatIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    contact: str = Field(min_length=5, max_length=120)
    message: str = Field(min_length=3, max_length=2000)
    source_page: Optional[str] = Field(default="", max_length=60)
    company_website: Optional[str] = ""


class StatusIn(BaseModel):
    status: Status


class LoginIn(BaseModel):
    email: EmailStr
    password: str


def hash_password(p: str) -> str:
    return bcrypt.hashpw(p.encode(), bcrypt.gensalt()).decode()


def verify_password(p: str, h: str) -> bool:
    return bcrypt.checkpw(p.encode(), h.encode())


def create_token(user_id: str, email: str, kind: str, delta: timedelta) -> str:
    payload = {"sub": user_id, "email": email, "type": kind, "exp": datetime.now(timezone.utc) + delta}
    return jwt.encode(payload, os.environ["JWT_SECRET"], algorithm=JWT_ALGORITHM)


async def get_current_user(request: Request) -> dict:
    token = request.cookies.get("access_token")
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:]
    if not token:
        raise HTTPException(401, "Not authenticated")
    try:
        payload = jwt.decode(token, os.environ["JWT_SECRET"], algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Invalid token")
    if payload.get("type") != "access":
        raise HTTPException(401, "Invalid token type")
    user = await db.users.find_one({"_id": ObjectId(payload["sub"])}, {"password_hash": 0})
    if not user or user.get("role") != "admin":
        raise HTTPException(401, "User not found")
    return {"id": str(user["_id"]), "email": user["email"], "name": user.get("name", ""), "role": user["role"]}


def set_auth_cookies(response: Response, user_id: str, email: str) -> str:
    access = create_token(user_id, email, "access", timedelta(hours=8))
    refresh = create_token(user_id, email, "refresh", timedelta(days=7))
    response.set_cookie("access_token", access, httponly=True, secure=True, samesite="none", max_age=28800, path="/")
    response.set_cookie("refresh_token", refresh, httponly=True, secure=True, samesite="none", max_age=604800, path="/")
    return access


@api.get("/")
async def root():
    return {"message": "Printemini API"}


@api.post("/auth/login")
async def login(body: LoginIn, request: Request, response: Response):
    email = body.email.lower()
    ident = f"{request.client.host if request.client else 'x'}:{email}"
    attempt = await db.login_attempts.find_one({"identifier": ident})
    now = datetime.now(timezone.utc)
    if attempt and attempt.get("count", 0) >= 5 and attempt.get("locked_until") and \
            datetime.fromisoformat(attempt["locked_until"]) > now:
        raise HTTPException(429, "Too many attempts. Try again in 15 minutes.")
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(body.password, user["password_hash"]):
        count = (attempt or {}).get("count", 0) + 1
        update = {"count": count}
        if count >= 5:
            update["locked_until"] = (now + timedelta(minutes=15)).isoformat()
        await db.login_attempts.update_one({"identifier": ident}, {"$set": update}, upsert=True)
        raise HTTPException(401, "Invalid email or password")
    await db.login_attempts.delete_many({"identifier": ident})
    token = set_auth_cookies(response, str(user["_id"]), email)
    return {"id": str(user["_id"]), "email": email, "name": user.get("name", ""), "role": user["role"], "token": token}


@api.post("/auth/logout")
async def logout(response: Response):
    response.delete_cookie("access_token", path="/")
    response.delete_cookie("refresh_token", path="/")
    return {"ok": True}


@api.get("/auth/me")
async def me(user: dict = Depends(get_current_user)):
    return user


@api.post("/leads", status_code=201)
async def create_lead(body: LeadIn):
    if body.company_website:
        return {"ok": True}
    if body.customer_type == "home" and body.visit_type == "remote":
        raise HTTPException(422, "Remote sessions are for business customers. Please choose an on-site visit or workshop drop-off.")
    lead = Lead(id=str(uuid.uuid4()), created_at=datetime.now(timezone.utc).isoformat(),
                **body.model_dump(exclude={"company_website"}, exclude_none=True))
    await db.leads.insert_one(lead.model_dump())
    owner = os.environ.get("OWNER_EMAIL", "").strip()
    if owner:
        try:
            sent = await send_email(to=owner, subject=f"New {lead.brand} request - {lead.company or lead.name or lead.phone}",
                                    html=lead_email_html(lead.model_dump()))
            if sent:
                await db.leads.update_one({"id": lead.id}, {"$set": {"email_sent": True}})
        except Exception as exc:
            logger.error("Lead email failed: %s", exc)
    return {"ok": True, "id": lead.id}


@api.post("/chat", status_code=201)
async def create_chat(body: ChatIn):
    if body.company_website:
        return {"ok": True}
    msg = {"id": str(uuid.uuid4()), "created_at": datetime.now(timezone.utc).isoformat(),
           **body.model_dump(exclude={"company_website"}), "email_sent": False}
    await db.chat_messages.insert_one(dict(msg))
    to = os.environ.get("CHAT_EMAIL", "").strip()
    if to:
        try:
            if await send_email(to=to, subject=f"New website chat message - {body.name}", html=chat_email_html(msg)):
                await db.chat_messages.update_one({"id": msg["id"]}, {"$set": {"email_sent": True}})
        except Exception as exc:
            logger.error("Chat email failed: %s", exc)
    return {"ok": True, "id": msg["id"]}


@api.get("/admin/leads")
async def list_leads(brand: Optional[str] = None, status: Optional[str] = None,
                     limit: int = Query(500, ge=1, le=1000), _: dict = Depends(get_current_user)):
    q = {"archived": {"$ne": True}}
    if brand:
        q["brand"] = brand
    if status:
        q["status"] = status
    docs = await db.leads.find(q, {"_id": 0}).sort("created_at", -1).limit(limit).to_list(limit)
    leads = [Lead(**d).model_dump() for d in docs]
    stats = {s: await db.leads.count_documents({"status": s, "archived": {"$ne": True}}) for s in ["new", "contacted", "scheduled", "resolved"]}
    stats["total"] = sum(stats.values())
    return {"leads": leads, "stats": stats}


@api.patch("/admin/leads/{lead_id}")
async def update_lead(lead_id: str, body: StatusIn, _: dict = Depends(get_current_user)):
    res = await db.leads.update_one({"id": lead_id}, {"$set": {"status": body.status}})
    if res.matched_count == 0:
        raise HTTPException(404, "Lead not found")
    return {"ok": True}


@api.delete("/admin/leads/{lead_id}")
async def delete_lead(lead_id: str, _: dict = Depends(get_current_user)):
    res = await db.leads.update_one({"id": lead_id}, {"$set": {"archived": True}})
    if res.matched_count == 0:
        raise HTTPException(404, "Lead not found")
    return {"ok": True}


app.include_router(api)
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)


async def seed_admin():
    email = os.environ["ADMIN_EMAIL"].lower()
    if await db.users.find_one({"email": email}) is None:
        await db.users.insert_one({"email": email, "password_hash": hash_password(os.environ["ADMIN_PASSWORD"]),
                                   "name": "Admin", "role": "admin", "created_at": datetime.now(timezone.utc).isoformat()})


@app.on_event("startup")
async def startup():
    app.state.index_task = asyncio.create_task(ensure_indexes())
    await seed_admin()


@app.on_event("shutdown")
async def shutdown():
    app.state.index_task.cancel()
    with suppress(asyncio.CancelledError):
        await app.state.index_task
    client.close()
