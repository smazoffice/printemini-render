import os
import re
import ipaddress
import logging
from html import escape
from html.parser import HTMLParser
from urllib.parse import urlparse

import httpx

logger = logging.getLogger(__name__)

EMAIL_BASE_URL = "https://integrations.emergentagent.com"

_SHORTENERS = ("bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "goo.gl", "rebrand.ly")
_CRED_ASK = ("reply with your password", "reply with the code", "send your password", "cvv",
             "send us your password", "enter your password below", "confirm your card number",
             "your full card number", "seed phrase", "recovery phrase", "verify your card",
             "social security number", "confirm your bank details")
_HOSTISH = re.compile(r"\b(?:https?://)?((?:[a-z0-9-]+\.)+[a-z]{2,})", re.I)


def _host_ok(host: str) -> bool:
    if not host or "xn--" in host:
        return False
    try:
        ipaddress.ip_address(host)
        return False
    except ValueError:
        pass
    return not any(host == s or host.endswith("." + s) for s in _SHORTENERS)


def _same_site(shown: str, real: str) -> bool:
    return shown == real or real.endswith("." + shown) or shown.endswith("." + real)


class _EmailScan(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags, self.urls, self.anchors = set(), [], []
        self._href, self._text = None, []

    def handle_starttag(self, tag, attrs):
        self.tags.add(tag.lower())
        self.urls += [v for k, v in attrs if k.lower() in ("href", "src") and v]
        if tag.lower() == "a":
            self._href = dict((k.lower(), v) for k, v in attrs).get("href")
            self._text = []

    def handle_data(self, data):
        if self._href is not None:
            self._text.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == "a" and self._href is not None:
            self.anchors.append((self._href, "".join(self._text)))
            self._href, self._text = None, []


def _assert_safe_email(subject: str, html: str) -> None:
    scan = _EmailScan()
    scan.feed(html)
    if scan.tags & {"form", "input", "textarea", "select"}:
        raise ValueError("No forms or input fields in email (G2)")
    body = f"{subject}\n{html}".lower()
    for p in _CRED_ASK:
        if p in body:
            raise ValueError(f"Email asks the recipient for credentials: {p!r} (G2)")
    for url in scan.urls:
        low = url.strip().lower()
        if low.startswith(("mailto:", "tel:", "cid:", "#")):
            continue
        if not low.startswith("https://"):
            raise ValueError(f"Email links/assets must be absolute https: {url!r} (G3)")
        host = urlparse(low).hostname or ""
        if not _host_ok(host) or urlparse(low).username is not None:
            raise ValueError(f"Shortened, numeric-host or credential-bearing URL: {url!r} (G3)")
    for href, text in scan.anchors:
        real = urlparse(href.strip().lower()).hostname or ""
        if not real:
            continue
        for m in _HOSTISH.finditer(text):
            if not _same_site(m.group(1).lower(), real):
                raise ValueError(f"Anchor text {m.group(1)!r} != real link host {real!r} (G3)")


async def send_email(*, to: str, subject: str, html: str) -> str | None:
    _assert_safe_email(subject, html)
    payload = {"to": [to], "subject": subject, "html": html, "from_name": os.environ["EMAIL_FROM_NAME"]}
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(f"{EMAIL_BASE_URL}/api/v1/email/send",
                                 headers={"X-Email-Key": os.environ["EMERGENT_EMAIL_KEY"]}, json=payload)
    if resp.status_code >= 400:
        try:
            info = resp.json()
        except ValueError:
            info = {}
        logger.warning("Email not sent (%s %s): %s", resp.status_code, info.get("code", ""), info.get("message", resp.text))
        return None
    return resp.json().get("id")


def chat_email_html(msg: dict) -> str:
    rows = [("Name", msg["name"]), ("Phone", msg["contact"]), ("Page", msg.get("source_page") or "-"),
            ("Message", msg["message"])]
    cells = "".join(
        f'<tr><td style="padding:6px 12px;color:#555;font-size:13px;vertical-align:top">{escape(k)}</td>'
        f'<td style="padding:6px 12px;font-size:14px;color:#111;white-space:pre-wrap">{escape(str(v))}</td></tr>' for k, v in rows)
    return (f'<table role="presentation" width="100%" style="font-family:Arial,sans-serif"><tr><td style="padding:24px">'
            f'<p style="font-size:16px;margin:0 0 12px">New quick chat message from the website</p>'
            f'<table role="presentation" style="border-collapse:collapse;border:1px solid #eee">{cells}</table>'
            f'<p style="font-size:12px;color:#888;margin-top:16px">Call the customer back on the phone number above.</p>'
            f'</td></tr></table>')


def lead_email_html(lead: dict) -> str:
    rows = [("Customer type", lead.get("customer_type") or "-"), ("Company", lead.get("company") or "-"), ("Name", lead.get("name") or "-"), ("Phone", lead["phone"]), ("Email", lead.get("email") or "-"),
            ("Brand", lead["brand"]), ("Model", lead.get("model") or "-"), ("Issue type", lead["issue_category"]),
            ("ZIP / address", lead.get("location") or "-"), ("Service type", lead.get("visit_type") or "-"), ("Preferred time", lead.get("preferred_time") or "-"),
            ("Page", lead.get("source_page") or "-"), ("Description", lead.get("description") or "-")]
    cells = "".join(
        f'<tr><td style="padding:6px 12px;color:#555;font-size:13px">{escape(k)}</td>'
        f'<td style="padding:6px 12px;font-size:14px;color:#111">{escape(str(v))}</td></tr>' for k, v in rows)
    name = escape(os.environ["EMAIL_FROM_NAME"])
    return (f'<table role="presentation" width="100%" style="font-family:Arial,sans-serif"><tr><td style="padding:24px">'
            f'<p style="font-size:16px;margin:0 0 12px">New printer service request</p>'
            f'<table role="presentation" style="border-collapse:collapse;border:1px solid #eee">{cells}</table>'
            f'<p style="font-size:12px;color:#888;margin-top:16px">Sent by {name} website. Open your admin page to update the status.</p>'
            f'</td></tr></table>')
