import { Layout } from "../components/site/Layout";
import { SITE, DISCLAIMER_FULL } from "../data/site";
import { useSeo } from "../lib/seo";

const DOCS = {
  privacy: {
    title: "Privacy Policy",
    sections: [
      ["What we collect", "When you send a repair request we collect your name, company name (if any), phone number, optional email address, printer brand and model, the location of the printer and your description of the problem."],
      ["Why we collect it", "We use this information only to contact you about your repair, arrange an on-site visit or workshop drop-off, prepare a quote and keep a record of the work done."],
      ["Chat messages", "Messages sent through the quick chat button (your name, contact details and message) are stored and forwarded to our team by email so we can reply. They are used only to answer you."],
      ["Who sees it", "Your request is stored securely and is visible only to Printemini staff. We do not sell, rent or share your information with third parties for marketing. We do not share it with printer manufacturers."],
      ["Advertising and analytics", "Our website may use cookies from advertising and analytics providers, such as Google Ads, to measure how visitors find us. These cookies do not give us access to your form details. You can control cookies in your browser settings."],
      ["How long we keep it", "We keep repair records for as long as needed to provide warranty cover and meet our accounting obligations, then delete them."],
      ["Your choices", `You can ask us to see, correct or delete your information at any time by calling ${SITE.phoneDisplay}, emailing ${SITE.email} or writing to us at ${SITE.address}.`],
    ],
  },
  terms: {
    title: "Terms of Service, Refund & Warranty Policy",
    sections: [
      ["Our service", "Printemini provides printer repair, maintenance and on-site network setup to home and business customers, plus booked remote troubleshooting sessions for business customers. Remote sessions are carried out with your staff by phone or video with a screen share you start; we never ask for unattended access to your devices."],
      ["Diagnostic fees", "Remote sessions, workshop diagnostics and on-site visits carry the fixed fees shown on our pricing section. The fee is due once the diagnosis is complete, whether or not you go ahead with the repair. Where stated, the workshop diagnostic fee is credited to the repair."],
      ["Quotes", "After diagnosis we give you a written quote for parts and labour. No work beyond the diagnosis is carried out, and no parts are ordered, without your approval."],
      ["Warranty", "Repairs are covered by a 90-day warranty on the parts we fit and the labour to fit them. The warranty does not cover consumables (ink, toner, paper), damage from misuse, liquid, power surges, or later work by others."],
      ["Refunds", "If a repair we carried out fails within the warranty period because of our parts or workmanship, we will repair it again at no charge. If we cannot fix it, we refund the repair charge for that fault. Diagnostic fees are non-refundable once the diagnosis has been performed."],
      ["Cancellations", "You can cancel an on-site visit free of charge up to 24 hours before the booked time."],
      ["Liability", "We take care with your equipment. Our liability is limited to the amount you paid for the repair concerned. We are not responsible for data stored on devices; please back up any stored scans or documents."],
      ["Manufacturer warranties", "We are an independent business. If your printer is still under its manufacturer's warranty, contact the manufacturer first, as third-party repairs may affect that cover."],
    ],
  },
  disclaimer: {
    title: "Disclaimer",
    sections: [
      ["Independent provider", DISCLAIMER_FULL],
      ["No affiliation", "Printemini is not affiliated with, endorsed by, sponsored by, or an authorised service provider of HP Inc., Canon Inc., Seiko Epson Corp., Brother Industries, Ltd. or any other printer manufacturer."],
      ["Trademarks", "HP, LaserJet, OfficeJet, DeskJet and PageWide are trademarks of HP Inc. Canon, PIXMA, MAXIFY, imageCLASS and imageRUNNER are trademarks of Canon Inc. Epson, EcoTank, WorkForce and SureColor are trademarks of Seiko Epson Corp. Brother is a trademark of Brother Industries, Ltd. These names are used only to describe the printers we repair. No manufacturer logos are used on this website."],
      ["Nature of our services", "We provide hands-on printer repair, maintenance, parts replacement and on-site network setup for homes and businesses, and booked remote troubleshooting sessions for business customers. Free help and drivers for your printer may be available directly from its manufacturer."],
    ],
  },
};

export default function LegalPage({ doc }) {
  const d = DOCS[doc];
  useSeo(`${d.title} | Printemini`, `${d.title} for Printemini, an independent printer repair and maintenance provider.`);
  return (
    <Layout>
      <article className="mx-auto max-w-3xl px-5 py-20 sm:px-8 sm:py-28" data-testid={`legal-page-${doc}`}>
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-[#175a93]">Legal</p>
        <h1 className="mt-4 font-display text-4xl font-black tracking-tight sm:text-5xl lg:text-6xl">{d.title}</h1>
        <div className="mt-12 space-y-10">
          {d.sections.map(([h, p]) => (
            <section key={h}>
              <h2 className="font-display text-xl font-bold">{h}</h2>
              <p className="mt-3 text-base leading-relaxed text-[#46586b]">{p}</p>
            </section>
          ))}
        </div>
        <p className="mt-16 border-t border-[#d6e6f3] pt-6 text-sm text-[#46586b]">Printemini · {SITE.address} · {SITE.phoneDisplay} · {SITE.email}</p>
      </article>
    </Layout>
  );
}
