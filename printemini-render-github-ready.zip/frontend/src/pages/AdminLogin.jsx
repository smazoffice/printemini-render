import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { useAuth, formatError } from "../lib/auth";
import { LogoMark } from "../components/site/Logo";

export default function AdminLogin() {
  const { user, login } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (user) nav("/admin/leads"); }, [user, nav]);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr("");
    try { await login(email, password); nav("/admin/leads"); }
    catch (ex) { setErr(formatError(ex.response?.data?.detail)); }
    finally { setBusy(false); }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0e2236] px-5">
      <form onSubmit={submit} className="w-full max-w-sm border border-[#23415e] bg-[#14304a] p-8 text-[#ffffff]" data-testid="admin-login-form">
        <LogoMark className="h-10 w-10" />
        <h1 className="mt-6 font-display text-3xl font-black">Admin sign in</h1>
        <p className="mt-2 text-sm text-[#c3d4e4]">Private area for Printemini staff.</p>
        <input className="field mt-8" type="email" required placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} data-testid="admin-login-input" />
        <input className="field mt-4" type="password" required placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} data-testid="admin-password-input" />
        {err && <p className="mt-4 text-sm text-red-400" data-testid="admin-login-error">{err}</p>}
        <button disabled={busy} className="mt-8 flex w-full items-center justify-center gap-2 rounded-full bg-[#1f6fb2] py-3 font-semibold hover:bg-[#175a93] disabled:opacity-60" data-testid="admin-login-submit">
          {busy && <Loader2 className="h-4 w-4 animate-spin" />}Sign in
        </button>
      </form>
    </div>
  );
}
