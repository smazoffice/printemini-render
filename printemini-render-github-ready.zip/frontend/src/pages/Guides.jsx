import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { Layout } from "../components/site/Layout";
import { Reveal, SectionLabel } from "../components/site/Motion";
import { GUIDES } from "../data/guides";
import { useSeo } from "../lib/seo";

export const GuideCard = ({ g, i }) => (
  <Reveal delay={i * 0.05}>
    <Link to={`/guides/${g.slug}`} data-testid={`guide-card-${g.slug}`} className="group flex h-full flex-col overflow-hidden rounded-3xl border border-[#d6e6f3] bg-white transition-[transform,box-shadow] duration-300 hover:-translate-y-1 hover:shadow-[0_30px_60px_-30px_rgba(31,111,178,0.4)]">
      <div className="aspect-[16/10] overflow-hidden bg-[#eef6fd]">
        <img src={g.img} alt={g.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105" />
      </div>
      <div className="flex flex-1 flex-col p-7">
        <p className="font-mono text-xs uppercase tracking-[0.18em] text-[#1f6fb2]">{g.brand} · {g.read}</p>
        <h2 className="mt-3 font-display text-2xl leading-tight">{g.title}</h2>
        <p className="mt-3 flex-1 text-sm leading-relaxed text-[#46586b]">{g.excerpt}</p>
        <span className="mt-6 inline-flex items-center gap-1 text-sm font-semibold text-[#175a93]">Read guide<ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></span>
      </div>
    </Link>
  </Reveal>
);

export default function Guides() {
  useSeo("Printer Help Guides: Jams, Print Quality & Wi-Fi | Printemini", "Free printer help guides for HP, Canon, Epson and Brother: paper jams, streaky prints, printhead errors, drum warnings, Wi-Fi problems and repair or replace advice.");
  return (
    <Layout>
      <section className="bg-[#eef6fd]">
        <div className="mx-auto max-w-[1400px] px-5 pb-16 pt-16 sm:px-8 sm:pt-20">
          <SectionLabel n="00">Printer guides</SectionLabel>
          <h1 className="max-w-4xl font-display text-4xl leading-[1.02] tracking-tight sm:text-5xl lg:text-6xl" data-testid="guides-heading">Printer help, written by repair technicians.</h1>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-[#46586b] md:text-lg">Plain answers to the problems we fix every week, with the safe checks you can do yourself first.</p>
        </div>
      </section>
      <section className="mx-auto grid max-w-[1400px] gap-5 px-5 py-16 sm:grid-cols-2 sm:px-8 lg:grid-cols-3" data-testid="guides-grid">
        {GUIDES.map((g, i) => <GuideCard key={g.slug} g={g} i={i} />)}
      </section>
    </Layout>
  );
}
