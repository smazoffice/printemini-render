import { useEffect, useState, useCallback } from "react";
import { Navigate } from "react-router-dom";
import { toast } from "sonner";
import { Phone, Download, LogOut, Archive, Mail } from "lucide-react";
import { useAuth, http, formatError } from "../lib/auth";
import { LogoMark } from "../components/site/Logo";

const STATUSES = ["new", "contacted", "scheduled", "resolved"];
const BRANDS = ["", "HP", "Canon", "Epson", "Brother", "Other"];

const toCsv = (rows) => {
  const cols = ["created_at", "customer_type", "company", "name", "phone", "email", "brand", "model", "issue_category", "location", "visit_type", "preferred_time", "status", "description"];
  const esc = (v) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [cols.join(","), ...rows.map((r) => cols.map((c) => esc(r[c])).join(","))].join("\n");
};

const Stat = ({ label, value, id }) => (
  <div className="border border-[#d6e6f3] bg-[#f6fafe] p-5" data-testid={`admin-stat-${id}`}>
    <p className="font-mono text-xs uppercase tracking-widest text-[#46586b]">{label}</p>
    <p className="mt-2 font-display text-4xl font-black">{value ?? 0}</p>
  </div>
);

export default function AdminLeads() {
  const { user, logout } = useAuth();
  const [data, setData] = useState({ leads: [], stats: {} });
  const [brand, setBrand] = useState("");
  const [status, setStatus] = useState("");

  const load = useCallback(async () => {
    try {
      const { data: d } = await http.get("/admin/leads", { params: { brand: brand || undefined, status: status || undefined } });
      setData({ leads: Array.isArray(d?.leads) ? d.leads : [], stats: d?.stats ?? {} });
    } catch (e) { toast.error(formatError(e.response?.data?.detail)); }
  }, [brand, status]);

  useEffect(() => { if (user) load(); }, [user, load]);

  if (user === null) return <div className="p-10 font-mono text-sm">Loading…</div>;
  if (user === false) return <Navigate to="/admin" replace />;

  const update = async (id, s) => { await http.patch(`/admin/leads/${id}`, { status: s }); toast.success("Status updated"); load(); };
  const archive = async (id) => { await http.delete(`/admin/leads/${id}`); toast.success("Lead archived"); load(); };
  const exportCsv = () => {
    const url = URL.createObjectURL(new Blob([toCsv(data.leads)], { type: "text/csv" }));
    const a = document.createElement("a"); a.href = url; a.download = "printemini-leads.csv"; a.click(); URL.revokeObjectURL(url);
  };
  const sel = "border border-[#d6e6f3] bg-white px-3 py-2 text-sm";

  return (
    <div className="min-h-screen bg-[#ffffff]">
      <header className="flex items-center justify-between border-b border-[#d6e6f3] px-5 py-4 sm:px-8">
        <div className="flex items-center gap-3"><LogoMark /><span className="font-display text-xl font-black">Leads</span></div>
        <button onClick={logout} className="flex items-center gap-2 text-sm" data-testid="admin-logout-btn"><LogOut className="h-4 w-4" />Sign out</button>
      </header>
      <main className="mx-auto max-w-[1400px] px-5 py-8 sm:px-8">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          <Stat label="Total" value={data.stats.total} id="total" />
          {STATUSES.map((s) => <Stat key={s} label={s} value={data.stats[s]} id={s} />)}
        </div>
        <div className="mt-8 flex flex-wrap items-center gap-3">
          <select className={sel} value={brand} onChange={(e) => setBrand(e.target.value)} data-testid="admin-filter-brand">{BRANDS.map((b) => <option key={b} value={b}>{b || "All brands"}</option>)}</select>
          <select className={sel} value={status} onChange={(e) => setStatus(e.target.value)} data-testid="admin-filter-status"><option value="">All statuses</option>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
          <button onClick={exportCsv} className="ml-auto flex items-center gap-2 rounded-full bg-[#0e2236] px-4 py-2 text-sm text-white" data-testid="admin-export-csv"><Download className="h-4 w-4" />Export CSV</button>
        </div>
        <div className="mt-6 overflow-x-auto border border-[#d6e6f3] bg-white">
          <table className="w-full min-w-[900px] text-left text-sm" data-testid="admin-leads-table">
            <thead className="bg-[#eef6fd] font-mono text-xs uppercase tracking-wider text-[#46586b]">
              <tr>{["Received", "Customer", "Printer", "Issue", "Location", "Status", ""].map((h) => <th key={h} className="px-4 py-3">{h}</th>)}</tr>
            </thead>
            <tbody>
              {data.leads.length === 0 && <tr><td colSpan={7} className="px-4 py-10 text-center text-[#46586b]" data-testid="admin-empty">No requests yet.</td></tr>}
              {data.leads.map((l) => (
                <tr key={l.id} className="border-t border-[#eef6fd] align-top" data-testid={`lead-row-${l.id}`}>
                  <td className="px-4 py-3 font-mono text-xs">{new Date(l.created_at).toLocaleString()}</td>
                  <td className="px-4 py-3"><p className="font-semibold">{l.company || l.name}</p>{l.company && l.name && <p className="text-xs text-[#46586b]">{l.name}</p>}<p className="text-[11px] uppercase tracking-wider text-[#46586b]">{l.customer_type}</p><a href={`tel:${l.phone}`} className="flex items-center gap-1 text-[#175a93]"><Phone className="h-3 w-3" />{l.phone}</a>{l.email && <a href={`mailto:${l.email}`} className="flex items-center gap-1 text-xs text-[#46586b]"><Mail className="h-3 w-3" />{l.email}</a>}</td>
                  <td className="px-4 py-3">{l.brand} {l.model}<p className="text-xs text-[#46586b]">{l.visit_type}{l.preferred_time ? ` · ${l.preferred_time}` : ""}</p></td>
                  <td className="max-w-xs px-4 py-3">{l.issue_category}<p className="text-xs text-[#46586b]">{l.description}</p></td>
                  <td className="px-4 py-3">{l.location || "—"}</td>
                  <td className="px-4 py-3"><select className={sel} value={l.status} onChange={(e) => update(l.id, e.target.value)} data-testid={`lead-status-${l.id}`}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select></td>
                  <td className="px-4 py-3"><button onClick={() => archive(l.id)} aria-label="Archive lead" data-testid={`lead-archive-${l.id}`}><Archive className="h-4 w-4 text-[#46586b] hover:text-[#0e2236]" /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
