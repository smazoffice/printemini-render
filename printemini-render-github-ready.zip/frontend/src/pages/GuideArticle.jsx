import { Link, useParams, Navigate } from "react-router-dom";
import { ArrowLeft, Phone } from "lucide-react";
import { Layout } from "../components/site/Layout";
import { Reveal } from "../components/site/Motion";
import { GUIDES } from "../data/guides";
import { SITE } from "../data/site";
import { useSeo } from "../lib/seo";

const Related = ({ slug }) => (
  <div className="mt-16 border-t border-[#d6e6f3] pt-10">
    <p className="font-mono text-xs uppercase tracking-[0.18em] text-[#46586b]">More guides</p>
    <ul className="mt-4 space-y-3">
      {GUIDES.filter((g) => g.slug !== slug).slice(0, 3).map((g) => (
        <li key={g.slug}><Link to={`/guides/${g.slug}`} data-testid={`related-guide-${g.slug}`} className="font-display text-lg text-[#0e2236] hover:text-[#1f6fb2]">{g.title}</Link></li>
      ))}
    </ul>
  </div>
);

const Article = ({ g }) => {
  useSeo(g.seoTitle, g.seoDesc);
  return (
    <Layout>
      <article className="mx-auto max-w-3xl px-5 py-14 sm:px-8 sm:py-20" data-testid={`guide-article-${g.slug}`}>
        <Link to="/guides" className="inline-flex items-center gap-2 text-sm text-[#175a93] hover:underline" data-testid="guide-back-link"><ArrowLeft className="h-4 w-4" />All guides</Link>
        <p className="mt-8 font-mono text-xs uppercase tracking-[0.18em] text-[#1f6fb2]">{g.brand} · {g.read}</p>
        <h1 className="mt-3 font-display text-4xl leading-[1.05] tracking-tight sm:text-5xl">{g.title}</h1>
        <p className="mt-5 text-lg leading-relaxed text-[#46586b]">{g.excerpt}</p>
        <div className="mt-10 aspect-[16/9] overflow-hidden rounded-3xl bg-[#eef6fd]">
          <img src={g.img} alt={g.title} className="h-full w-full object-cover" />
        </div>
        <div className="mt-12 space-y-10">
          {g.sections.map((s) => (
            <Reveal key={s.h}>
              <h2 className="font-display text-2xl">{s.h}</h2>
              <p className="mt-3 text-base leading-relaxed text-[#46586b] md:text-lg">{s.p}</p>
            </Reveal>
          ))}
        </div>
        <div className="mt-14 rounded-3xl bg-[#0e2236] p-8 text-white sm:p-10" data-testid="guide-cta">
          <h2 className="font-display text-2xl sm:text-3xl">Still not fixed?</h2>
          <p className="mt-3 text-[#c3d4e4]">Book an on-site or workshop repair. You get a written quote before any work starts.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/#contact" data-testid="guide-book-btn" className="rounded-full bg-[#1f6fb2] px-6 py-3 text-sm font-semibold hover:bg-[#175a93]">Book a repair</Link>
            <a href={SITE.phoneHref} data-testid="guide-call-btn" className="inline-flex items-center gap-2 rounded-full border border-[#34587a] px-6 py-3 font-mono text-sm hover:border-[#8fc6ef]"><Phone className="h-4 w-4" />{SITE.phoneDisplay}</a>
          </div>
        </div>
        <Related slug={g.slug} />
      </article>
    </Layout>
  );
};

export default function GuideArticle() {
  const { slug } = useParams();
  const g = GUIDES.find((x) => x.slug === slug);
  return g ? <Article g={g} /> : <Navigate to="/guides" replace />;
}
