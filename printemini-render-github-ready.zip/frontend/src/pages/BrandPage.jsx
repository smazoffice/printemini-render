import { Layout } from "../components/site/Layout";
import { Hero } from "../components/site/Hero";
import { Marquee } from "../components/site/Marquee";
import { BrandLinks } from "../components/site/BrandLinks";
import { Process } from "../components/site/Process";
import { Pricing } from "../components/site/Pricing";
import { RequestForm } from "../components/site/RequestForm";
import { Faq } from "../components/site/Faq";
import { ProblemFinder } from "../components/site/ProblemFinder";
import { Link } from "react-router-dom";
import { GuideCard } from "./Guides";
import { GUIDES } from "../data/guides";
import { Reveal, SectionLabel } from "../components/site/Motion";
import { BRANDS } from "../data/brands";
import { useSeo } from "../lib/seo";

const Intro = ({ b }) => (
  <section className="mx-auto grid max-w-[1400px] gap-12 px-5 py-24 sm:px-8 sm:py-32 lg:grid-cols-12" data-testid="brand-intro-section">
    <Reveal className="lg:col-span-5">
      <SectionLabel n="01">{b.key} printers we work on</SectionLabel>
      <h2 className="font-display text-4xl font-black leading-[1] tracking-tight sm:text-5xl">Model families on our bench.</h2>
      <ul className="mt-8 flex flex-wrap gap-2">
        {b.models.map((m) => <li key={m} className="border border-[#d6e6f3] bg-[#f6fafe] px-3 py-1.5 font-mono text-xs">{b.key} {m}</li>)}
      </ul>
    </Reveal>
    <Reveal delay={0.1} className="space-y-6 text-base leading-relaxed text-[#46586b] md:text-lg lg:col-span-7">
      {b.intro.map((p) => <p key={p.slice(0, 20)}>{p}</p>)}
    </Reveal>
  </section>
);

const Faults = ({ b }) => (
  <section className="border-y border-[#d6e6f3] bg-[#eef6fd]" data-testid="brand-faults-section">
    <div className="mx-auto max-w-[1400px] px-5 py-24 sm:px-8 sm:py-32">
      <Reveal className="mb-12 max-w-3xl">
        <SectionLabel n="02">Common {b.key} repairs</SectionLabel>
        <h2 className="font-display text-4xl font-black leading-[1] tracking-tight sm:text-5xl">What we fix, part by part.</h2>
      </Reveal>
      <div className="divide-y divide-[#d6e6f3] border-y border-[#d6e6f3]">
        {b.faults.map((f, i) => (
          <Reveal key={f.t} delay={i * 0.05} className="group grid gap-3 py-7 transition-colors md:grid-cols-12 md:items-baseline">
            <span className="font-mono text-xs text-[#175a93] md:col-span-1">{String(i + 1).padStart(2, "0")}</span>
            <h3 className="font-display text-xl font-bold transition-transform duration-300 group-hover:translate-x-2 sm:text-2xl md:col-span-6">{f.t}</h3>
            <p className="text-sm leading-relaxed text-[#46586b] md:col-span-5">{f.d}</p>
          </Reveal>
        ))}
      </div>
    </div>
  </section>
);

const BrandGuides = ({ b }) => {
  const list = [...GUIDES.filter((g) => g.brand === b.key), ...GUIDES.filter((g) => g.brand === "All brands")].slice(0, 3);
  return (
    <section className="border-t border-[#d6e6f3] bg-[#f6fafe]" data-testid="brand-guides-section">
      <div className="mx-auto max-w-[1400px] px-5 py-24 sm:px-8">
        <Reveal className="mb-10 flex flex-wrap items-end justify-between gap-4">
          <div>
            <SectionLabel n="08">{b.key} help guides</SectionLabel>
            <h2 className="font-display text-4xl leading-[1.05] tracking-tight sm:text-5xl">Fix it yourself first.</h2>
          </div>
          <Link to="/guides" data-testid="brand-guides-all-link" className="text-sm font-semibold text-[#175a93] hover:underline">All printer guides</Link>
        </Reveal>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((g, i) => <GuideCard key={g.slug} g={g} i={i} />)}
        </div>
      </div>
    </section>
  );
};

export default function BrandPage({ brand }) {
  const b = BRANDS[brand];
  useSeo(b.seoTitle, b.seoDesc);
  return (
    <Layout extraDisclaimer={b.disclaimer}>
      <Hero eyebrow={b.eyebrow} lines={b.lines} accent={b.accentLine} sub={b.sub} img={b.img}
        alt={`Printemini technician repairing ${b.key} printer hardware at the workshop`}
        tags={[{ label: `${b.key} hardware repair`, pos: "-left-3 top-10 sm:-left-8" }, { label: "Quote before work", pos: "-right-2 bottom-16 sm:-right-6" }]} />
      <div className="h-4" />
      <Marquee items={[`${b.key} printer repair`, ...b.models.slice(0, 4), "Home & business", "Quote before work"]} />
      <ProblemFinder brand={b.key} />
      <Intro b={b} />
      <Faults b={b} />
      <Process />
      <Pricing />
      <RequestForm key={brand} brand={b.key} />
      <Faq items={b.faq} />
      <BrandGuides b={b} />
      <BrandLinks exclude={brand} n="09" />
    </Layout>
  );
}
