import { Layout } from "../components/site/Layout";
import { Hero } from "../components/site/Hero";
import { Marquee } from "../components/site/Marquee";
import { BrandLinks } from "../components/site/BrandLinks";
import { ServicesBento } from "../components/site/ServicesBento";
import { Process } from "../components/site/Process";
import { Pricing } from "../components/site/Pricing";
import { About } from "../components/site/About";
import { RequestForm } from "../components/site/RequestForm";
import { Faq } from "../components/site/Faq";
import { ProblemFinder } from "../components/site/ProblemFinder";
import { useSeo } from "../lib/seo";

const FAQ = [
  { q: "Are you a manufacturer's support line?", a: "No. Printemini is an independent third-party repair business. We are not affiliated with, endorsed by or sponsored by HP Inc., Canon Inc., Seiko Epson Corp. or any other printer manufacturer." },
  { q: "Do you repair printers for home users?", a: "Yes. We repair home and home-office printers on site or in our workshop. Booked remote troubleshooting sessions are available for business customers." },
  { q: "How does remote troubleshooting work for businesses?", a: "Your business books a remote session for a set time. A technician calls your staff and, with your permission, uses a screen share you start, to fix drivers, print queues, network printing and scan settings. If the fault is mechanical, we book an on-site visit instead." },
  { q: "How do I know if I need on-site repair?", a: "Use the problem finder on this page. Grinding noises, repeated jams, smudged or faded prints and error codes that point to a part almost always need hands-on repair." },
  { q: "How much does a visit cost?", a: "The on-site visit fee covers travel, diagnosis and the first 30 minutes of labour. After diagnosis you get a written quote, and nothing more is charged unless you approve it." },
  { q: "What if the printer isn't worth repairing?", a: "We tell you. If the repair would cost more than the printer is worth, we say so and you only pay the diagnostic fee." },
];

export default function Home() {
  useSeo("Printer Repair for Home & Business, On-Site | Printemini", "Independent on-site and workshop printer repair for homes and businesses: HP, Canon, Epson and Brother. Remote sessions for offices. Written quote first.");
  return (
    <Layout>
      <Hero
        eyebrow="Home & business printer repair"
        lines={["Printer repair", "for home & office,", "done right."]}
        accent={1}
        sub="On-site and workshop repair for HP, Canon, Epson and Brother printers at home or at work, plus booked remote troubleshooting sessions for business customers."
        img="/images/office.jpg"
        alt="Technician opening an office printer to inspect the paper path"
        tags={[{ label: "Paper path — inspected", pos: "-left-3 top-10 sm:-left-8" }, { label: "Home & office visits", pos: "-right-2 bottom-16 sm:-right-6" }]}
      />
      <Marquee />
      <ProblemFinder />
      <BrandLinks />
      <ServicesBento />
      <Process />
      <Pricing />
      <About />
      <RequestForm />
      <Faq items={FAQ} />
    </Layout>
  );
}
