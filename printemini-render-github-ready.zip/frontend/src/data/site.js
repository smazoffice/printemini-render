export const SITE = {
  name: "Printemini",
  phoneDisplay: "+1 (804) 656-5569",
  phoneHref: "tel:+18046565569",
  address: "1207 Delaware Ave #2392, Wilmington, DE 19806",
  email: "support@printemini.com",
  hours: "[Your business hours, e.g. Mon–Fri 8:00–18:00]",
};

export const DISCLAIMER_SHORT =
  "Printemini is an independent third-party printer repair provider. Not affiliated with, endorsed by, or sponsored by HP Inc., Canon Inc. or Seiko Epson Corp.";

export const DISCLAIMER_FULL =
  "Printemini is an independent third-party IT and hardware repair provider serving home and business customers. All product names, logos, and brands are property of their respective owners. Use of these names does not imply endorsement.";

export const NAV = [
  { label: "Services", to: "/#services", id: "services" },
  { label: "About Us", to: "/#about", id: "about" },
  { label: "Guides", to: "/guides", id: "guides" },
  { label: "Contact", to: "/#contact", id: "contact" },
];

export const BRAND_LINKS = [
  { label: "HP printers", to: "/hp-printer-repair", id: "hp" },
  { label: "Canon printers", to: "/canon-printer-repair", id: "canon" },
  { label: "Epson printers", to: "/epson-printer-repair", id: "epson" },
  { label: "Brother printers", to: "/brother-printer-repair", id: "brother" },
];

export const SERVICES = [
  { id: "paper-jam", code: "01", title: "Paper Jam & Roller Replacement", body: "Worn pickup, feed and separation rollers are the usual reason a printer keeps jamming. We open the paper path, remove debris, and fit new rollers and pads so sheets feed straight again.", tag: "Paper path", img: "/images/hero.jpg", span: "lg:col-span-7 lg:row-span-2" },
  { id: "remote", code: "02", title: "Remote Troubleshooting for Offices", body: "Book a remote session and our technician connects with your IT contact by phone or video with screen share: print queues, driver deployment, network printing, scan-to-email and error codes, fixed without a site visit.", tag: "Remote · business only", span: "lg:col-span-5" },
  { id: "fuser-printhead", code: "03", title: "Fuser & Printhead Repair", body: "Smudged toner, wrinkled pages, streaks or missing colours. We test and replace fuser assemblies on laser models and clean, purge or replace printheads on inkjets.", tag: "Print quality", span: "lg:col-span-5" },
  { id: "network-setup", code: "04", title: "Office Network Printer Setup", body: "On-site configuration of office printers on your Wi-Fi or wired network: static IP addressing, shared printing for every desk, and scan-to-email or scan-to-folder.", tag: "On-site setup", span: "lg:col-span-4" },
  { id: "maintenance", code: "05", title: "Preventive Maintenance", body: "Scheduled visits that clean the paper path, check wear parts, replace maintenance kits and run test pages, so small faults are caught before they stop your office.", tag: "Scheduled care", img: "/images/trays.jpg", span: "lg:col-span-4" },
  { id: "parts", code: "06", title: "Parts Replacement", body: "Fusers, rollers, trays, duplex units, maintenance boxes and power supplies. You see the quote before any part is ordered or fitted.", tag: "Hardware", span: "lg:col-span-4" },
];

export const PRICING = [
  { id: "remote", name: "Remote session", price: "$59", unit: "per 30 minutes", note: "Business customers · phone or video", items: ["Booked time with a technician", "Drivers, queues, network and scan setup", "If it needs hands-on work, we quote a visit"] },
  { id: "bench", name: "Workshop diagnostic", price: "$49", unit: "per device", note: "Drop off at our workshop", items: ["Hands-on inspection of the printer", "Written fault report and repair quote", "Fee credited to the repair if you go ahead"] },
  { id: "onsite", name: "On-site visit", price: "$89", unit: "call-out + diagnosis", note: "Technician comes to you", featured: true, items: ["Technician visits your home or office", "Diagnosis and first 30 minutes of labour", "Quote approved by you before parts are fitted"] },
  { id: "fleet", name: "Office maintenance", price: "from $129", unit: "per device / visit", note: "Scheduled preventive care", items: ["Cleaning, wear-part check and test prints", "Network and scanning check-up", "Visit report for every device"] },
];

export const STEPS = [
  { n: "01", t: "Request", d: "Send the form or call us with the printer model and what it is doing." },
  { n: "02", t: "On-site, drop-off or remote", d: "A technician visits your home or office, you drop the printer at our workshop, or business customers book a remote session." },
  { n: "03", t: "Quote first", d: "You get a written diagnosis and price. No work starts until you approve it." },
  { n: "04", t: "Repair & test", d: "We repair, run test prints in front of you and back the work with our warranty." },
];

export const MARQUEE = ["Printer repair for home & business", "Remote troubleshooting sessions", "On-site printer repair", "Roller & fuser replacement", "Office network setup", "Quote before any work"];
