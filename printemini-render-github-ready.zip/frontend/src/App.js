import { useEffect } from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Lenis from "lenis";
import { Toaster } from "./components/ui/sonner";
import { AuthProvider } from "./lib/auth";
import Home from "./pages/Home";
import BrandPage from "./pages/BrandPage";
import LegalPage from "./pages/LegalPage";
import AdminLogin from "./pages/AdminLogin";
import AdminLeads from "./pages/AdminLeads";
import Guides from "./pages/Guides";
import GuideArticle from "./pages/GuideArticle";

const SmoothScroll = () => {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    const lenis = new Lenis({ duration: 1.15, smoothWheel: true });
    window.__lenis = lenis;
    let id;
    const raf = (t) => { lenis.raf(t); id = requestAnimationFrame(raf); };
    id = requestAnimationFrame(raf);
    return () => { cancelAnimationFrame(id); lenis.destroy(); window.__lenis = null; };
  }, []);
  useEffect(() => {
    const t = setTimeout(() => {
      const el = hash ? document.querySelector(hash) : null;
      if (el && window.__lenis) window.__lenis.scrollTo(el, { offset: -90 });
      else if (!hash) window.__lenis ? window.__lenis.scrollTo(0, { immediate: true }) : window.scrollTo(0, 0);
    }, 60);
    return () => clearTimeout(t);
  }, [pathname, hash]);
  return null;
};

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <SmoothScroll />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/hp-printer-repair" element={<BrandPage brand="hp" />} />
          <Route path="/canon-printer-repair" element={<BrandPage brand="canon" />} />
          <Route path="/epson-printer-repair" element={<BrandPage brand="epson" />} />
          <Route path="/brother-printer-repair" element={<BrandPage brand="brother" />} />
          <Route path="/guides" element={<Guides />} />
          <Route path="/guides/:slug" element={<GuideArticle />} />
          <Route path="/privacy-policy" element={<LegalPage doc="privacy" />} />
          <Route path="/terms-and-warranty" element={<LegalPage doc="terms" />} />
          <Route path="/disclaimer" element={<LegalPage doc="disclaimer" />} />
          <Route path="/admin" element={<AdminLogin />} />
          <Route path="/admin/leads" element={<AdminLeads />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </BrowserRouter>
      <Toaster position="bottom-right" />
    </AuthProvider>
  );
}

export default App;
