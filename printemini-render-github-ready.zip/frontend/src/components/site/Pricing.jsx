import { Check } from "lucide-react";
import { Reveal, SectionLabel } from "./Motion";
import { PRICING } from "../../data/site";

export const Pricing = () => (
  <section id="pricing" className="mx-auto max-w-[1400px] px-5 py-24 sm:px-8 sm:py-32" data-testid="pricing-section">
    <Reveal className="mb-14 max-w-3xl">
      <SectionLabel n="04">Transparent pricing</SectionLabel>
      <h2 className="font-display text-4xl font-black leading-[1] tracking-tight sm:text-5xl">Know the fee before we start.</h2>
      <p className="mt-5 text-base leading-relaxed text-[#46586b]">Diagnostic fees are fixed. Repair labour and parts are quoted in writing after diagnosis, and nothing is fitted until you approve the quote.</p>
    </Reveal>
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {PRICING.map((p, i) => (
        <Reveal key={p.id} delay={i * 0.08}>
          <div data-testid={`pricing-card-${p.id}`} className={`flex h-full flex-col rounded-3xl border p-8 transition-transform duration-300 hover:-translate-y-1 ${p.featured ? "border-[#0e2236] bg-[#0e2236] text-[#ffffff]" : "border-[#d6e6f3] bg-[#f6fafe]"}`}>
            <div className="flex items-center justify-between">
              <p className="font-mono text-xs uppercase tracking-[0.2em] text-[#1f6fb2]">{p.note}</p>
              {p.featured && <span className="rounded-full bg-[#1f6fb2] px-2.5 py-1 text-[11px] font-semibold text-white">Most booked</span>}
            </div>
            <h3 className="mt-6 font-display text-2xl font-bold">{p.name}</h3>
            <p className="mt-4 font-display text-5xl font-black tracking-tight" data-testid={`pricing-price-${p.id}`}>{p.price}</p>
            <p className={`mt-1 text-sm ${p.featured ? "text-[#c3d4e4]" : "text-[#46586b]"}`}>{p.unit}</p>
            <ul className="mt-8 space-y-3">
              {p.items.map((it) => (
                <li key={it} className="flex gap-3 text-sm"><Check className="mt-0.5 h-4 w-4 shrink-0 text-[#1f6fb2]" />{it}</li>
              ))}
            </ul>
          </div>
        </Reveal>
      ))}
    </div>
    <p className="mt-6 text-sm text-[#46586b]">Prices in USD, before tax. Parts are charged at the price shown on your approved quote.</p>
  </section>
);
