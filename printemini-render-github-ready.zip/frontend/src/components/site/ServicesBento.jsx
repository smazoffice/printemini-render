import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { Reveal, SectionLabel } from "./Motion";
import { SERVICES } from "../../data/site";

const Card = ({ s, i }) => {
  const dark = i === 1 || i === 4;
  return (
    <motion.article
      data-testid={`bento-card-${s.id}`}
      initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.12 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1], delay: i * 0.06 }}
      whileHover={{ y: -4 }}
      className={`group relative flex min-h-[260px] flex-col justify-between overflow-hidden rounded-3xl border p-7 sm:p-8 ${s.span} ${dark ? "border-[#23415e] bg-[#0e2236] text-[#ffffff]" : "border-[#d6e6f3] bg-[#f6fafe]"}`}
    >
      {s.img && (
        <div className="absolute inset-0">
          <img src={s.img} alt={`${s.title} at the Printemini workshop`} loading="lazy" className="h-full w-full object-cover grayscale transition-[filter,transform] duration-700 group-hover:scale-105 group-hover:grayscale-0" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0e2236] via-[#0e2236]/70 to-[#0e2236]/10" />
        </div>
      )}
      <div className="relative flex items-start justify-between">
        <span className={`font-mono text-xs uppercase tracking-[0.2em] ${s.img || dark ? "text-[#b9dcf5]" : "text-[#175a93]"}`}>{s.code} / {s.tag}</span>
        <ArrowUpRight className={`h-5 w-5 transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1 ${s.img || dark ? "text-white" : ""}`} />
      </div>
      <div className={`relative mt-16 ${s.img ? "text-[#ffffff]" : ""}`}>
        <h3 className="font-display text-2xl font-black tracking-tight sm:text-3xl">{s.title}</h3>
        <p className={`mt-3 max-w-xl text-sm leading-relaxed sm:text-base ${s.img || dark ? "text-[#d5e2ee]" : "text-[#46586b]"}`}>{s.body}</p>
      </div>
    </motion.article>
  );
};

export const ServicesBento = () => (
  <section id="services" className="mx-auto max-w-[1400px] px-5 py-24 sm:px-8 sm:py-32" data-testid="services-section">
    <Reveal className="mb-14 grid gap-6 lg:grid-cols-12 lg:items-end">
      <div className="lg:col-span-7">
        <SectionLabel n="02">Services</SectionLabel>
        <h2 className="font-display text-4xl font-black leading-[1] tracking-tight sm:text-5xl lg:text-6xl">Fixed remotely.<br /><span className="text-[#1f6fb2]">Repaired on site.</span></h2>
      </div>
      <p className="text-base leading-relaxed text-[#46586b] lg:col-span-5">Software, driver and network faults are solved in a booked remote session with your staff. Worn parts and mechanical faults get a technician with tools at your home or office. Home users get on-site or workshop repair. Business customers can also book remote troubleshooting sessions.</p>
    </Reveal>
    <div className="grid auto-rows-[minmax(260px,auto)] grid-cols-1 gap-4 lg:grid-cols-12">
      {SERVICES.map((s, i) => <Card key={s.id} s={s} i={i} />)}
    </div>
  </section>
);
