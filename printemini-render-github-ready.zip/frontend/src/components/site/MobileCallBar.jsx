import { Link } from "react-router-dom";
import { Phone, Wrench } from "lucide-react";
import { SITE } from "../../data/site";

export const MobileCallBar = () => (
  <div className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-2 border-t border-[#23415e] bg-[#0e2236] md:hidden">
    <a href={SITE.phoneHref} data-testid="mobile-call-btn" className="flex items-center justify-center gap-2 py-4 text-sm font-semibold text-white"><Phone className="h-4 w-4" />Call to book</a>
    <Link to="/#contact" data-testid="mobile-book-btn" className="flex items-center justify-center gap-2 bg-[#1f6fb2] py-4 text-sm font-semibold text-white"><Wrench className="h-4 w-4" />Request visit</Link>
  </div>
);
