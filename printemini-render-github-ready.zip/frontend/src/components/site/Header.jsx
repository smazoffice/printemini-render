import { useState } from "react";
import { Link } from "react-router-dom";
import { Menu, Phone, MapPin, ChevronDown } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "../ui/sheet";
import { Logo } from "./Logo";
import { SITE, NAV, BRAND_LINKS } from "../../data/site";

const BrandMenu = () => (
  <div className="group relative">
    <button className="flex items-center gap-1 text-sm font-medium text-[#0e2236] hover:text-[#175a93]" data-testid="header-nav-brands">
      Printers we repair <ChevronDown className="h-3.5 w-3.5 transition-transform group-hover:rotate-180" />
    </button>
    <div className="invisible absolute left-0 top-full z-50 pt-3 opacity-0 transition-[opacity,visibility] duration-200 group-hover:visible group-hover:opacity-100">
      <div className="w-56 border border-[#d6e6f3] bg-[#ffffff] p-2 shadow-xl">
        {BRAND_LINKS.map((b) => (
          <Link key={b.id} to={b.to} data-testid={`header-nav-${b.id}`} className="block px-3 py-2 text-sm hover:bg-[#eef6fd]">{b.label}</Link>
        ))}
      </div>
    </div>
  </div>
);

const MobileMenu = () => {
  const [open, setOpen] = useState(false);
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <button className="lg:hidden" aria-label="Open menu" data-testid="mobile-menu-btn"><Menu className="h-6 w-6" /></button>
      </SheetTrigger>
      <SheetContent className="bg-[#ffffff]">
        <SheetTitle className="font-display text-2xl font-black">Menu</SheetTitle>
        <nav className="mt-8 flex flex-col gap-4">
          {[...NAV, ...BRAND_LINKS].map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} data-testid={`mobile-nav-${n.id}`} className="font-display text-2xl font-bold">{n.label}</Link>
          ))}
        </nav>
        <p className="mt-10 text-sm text-[#46586b]">{SITE.address}</p>
      </SheetContent>
    </Sheet>
  );
};

export const Header = () => (
  <header className="sticky top-0 z-50">
    <div className="border-b border-[#d6e6f3] bg-[#ffffff]/85 backdrop-blur-xl">
      <div className="mx-auto flex max-w-[1400px] items-center justify-between gap-6 px-5 py-3.5 sm:px-8">
        <Logo />
        <nav className="hidden items-center gap-7 lg:flex">
          {NAV.map((n) => (
            <Link key={n.id} to={n.to} data-testid={`header-nav-${n.id}`} className="text-sm font-medium hover:text-[#175a93]">{n.label}</Link>
          ))}
          <BrandMenu />
        </nav>
        <div className="flex items-center gap-4">
          <div className="hidden text-right xl:block">
            <a href={SITE.phoneHref} data-testid="header-phone-cta" className="flex items-center justify-end gap-2 font-mono text-sm font-semibold">
              <span className="pulse-dot h-2 w-2 rounded-full bg-emerald-500" /> <Phone className="h-3.5 w-3.5" /> {SITE.phoneDisplay}
            </a>
            <p className="flex items-center justify-end gap-1 text-[11px] text-[#46586b]"><MapPin className="h-3 w-3" />{SITE.address}</p>
          </div>
          <a href={SITE.phoneHref} className="flex h-10 w-10 items-center justify-center rounded-full bg-[#0e2236] text-white xl:hidden" aria-label="Call Printemini" data-testid="header-phone-icon"><Phone className="h-4 w-4" /></a>
          <Link to="/#contact" data-testid="header-schedule-btn" className="hidden rounded-full bg-[#1f6fb2] px-5 py-2.5 text-sm font-semibold text-white transition-[transform,background-color] duration-200 hover:-translate-y-0.5 hover:bg-[#175a93] active:scale-95 sm:inline-block">Book a repair</Link>
          <MobileMenu />
        </div>
      </div>
      <p data-testid="header-affiliation-note" className="border-t border-[#d6e6f3] bg-[#f6fafe] px-4 py-1.5 text-center text-[12px] text-[#46586b]">Printemini is an independent repair company for home and business customers, not affiliated with HP, Canon, Epson or Brother.</p>
    </div>
  </header>
);
