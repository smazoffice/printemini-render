import { Reveal, SectionLabel } from "./Motion";
import { STEPS } from "../../data/site";

export const Process = () => (
  <section className="relative overflow-hidden bg-[#0e2236] py-24 text-[#ffffff] sm:py-32" data-testid="process-section">
    <div className="grid-lines pointer-events-none absolute inset-0 opacity-30 invert" />
    <div className="relative mx-auto max-w-[1400px] px-5 sm:px-8">
      <Reveal className="mb-16 max-w-3xl">
        <SectionLabel n="03" dark>How a repair works</SectionLabel>
        <h2 className="font-display text-4xl font-black leading-[1] tracking-tight sm:text-5xl">Four steps. <span className="text-[#8fc6ef]">One written quote.</span></h2>
      </Reveal>
      <div className="grid gap-px bg-[#23415e] sm:grid-cols-2 lg:grid-cols-4">
        {STEPS.map((s, i) => (
          <Reveal key={s.n} delay={i * 0.08} className="bg-[#0e2236] p-8">
            <p className="font-display text-7xl font-black text-transparent [-webkit-text-stroke:1.2px_#8fc6ef]">{s.n}</p>
            <h3 className="mt-8 font-display text-2xl font-bold">{s.t}</h3>
            <p className="mt-3 text-sm leading-relaxed text-[#c3d4e4]">{s.d}</p>
          </Reveal>
        ))}
      </div>
    </div>
  </section>
);
