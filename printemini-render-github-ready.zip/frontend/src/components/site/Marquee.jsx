import { Asterisk } from "lucide-react";
import { MARQUEE } from "../../data/site";

export const Marquee = ({ items = MARQUEE }) => {
  const row = [...items, ...items];
  return (
    <div className="overflow-hidden border-y border-[#d6e6f3] bg-[#eef6fd] py-6" data-testid="editorial-marquee">
      <div className="marquee-track flex items-center">
        {row.map((t, i) => (
          <span key={i} className="flex items-center whitespace-nowrap font-display text-3xl font-extrabold tracking-tight text-[#0e2236] sm:text-5xl">
            <span className={i % 2 ? "text-transparent [-webkit-text-stroke:1.2px_#0e2236]" : ""}>{t}</span>
            <Asterisk className="mx-8 h-7 w-7 text-[#1f6fb2] sm:h-9 sm:w-9" strokeWidth={2.5} />
          </span>
        ))}
      </div>
    </div>
  );
};
