import { Link } from "react-router-dom";

export const LogoMark = ({ className = "h-9 w-9" }) => (
  <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
    <rect width="32" height="32" rx="8" fill="#0E2236" />
    <path d="M10 25V7h7.2a5.6 5.6 0 0 1 0 11.2H10" fill="none" stroke="#FBFBFA" strokeWidth="3" strokeLinejoin="round" />
    <rect x="15" y="21.5" width="10" height="3" rx="1" fill="#4BA3E3" />
  </svg>
);

export const Logo = ({ dark = false }) => (
  <Link to="/" data-testid="header-logo" className="group flex items-center gap-2.5" aria-label="Printemini home">
    <span className="transition-transform duration-500 group-hover:rotate-[-8deg]"><LogoMark /></span>
    <span className={`font-display text-xl font-black tracking-tight ${dark ? "text-[#ffffff]" : "text-[#0e2236]"}`}>
      printemini<span className="text-[#1f6fb2]">.</span>
    </span>
  </Link>
);
