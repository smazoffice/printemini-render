import { Link } from "react-router-dom";
import { Logo } from "./Logo";
import { SITE, NAV, BRAND_LINKS, DISCLAIMER_FULL } from "../../data/site";

const Col = ({ title, links }) => (
  <div>
    <p className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-[#9fb4c8]">{title}</p>
    <ul className="space-y-2.5">
      {links.map((l) => (
        <li key={l.to}><Link to={l.to} data-testid={l.tid} className="text-sm text-[#d5e2ee] transition-colors hover:text-[#8fc6ef]">{l.label}</Link></li>
      ))}
    </ul>
  </div>
);

export const Footer = ({ extraDisclaimer }) => (
  <footer className="relative bg-[#0e2236] pb-24 pt-20 text-[#ffffff] md:pb-10">
    <div className="mx-auto max-w-[1400px] px-5 sm:px-8">
      <div className="grid gap-12 md:grid-cols-12">
        <div className="md:col-span-5">
          <Logo dark />
          <p className="mt-6 max-w-sm text-sm leading-relaxed text-[#c3d4e4]">Printer repair for homes and businesses, maintenance, office network setup and remote sessions for offices.</p>
          <a href={SITE.phoneHref} data-testid="footer-phone-link" className="mt-6 block font-display text-3xl font-black hover:text-[#8fc6ef]">{SITE.phoneDisplay}</a>
          <p className="mt-2 text-sm text-[#c3d4e4]" data-testid="footer-address">{SITE.address}</p>
          <a href={`mailto:${SITE.email}`} data-testid="footer-email-link" className="text-sm text-[#c3d4e4] hover:text-[#8fc6ef]">{SITE.email}</a>
          <p className="text-sm text-[#c3d4e4]">{SITE.hours}</p>
        </div>
        <div className="grid grid-cols-2 gap-8 md:col-span-7 md:grid-cols-3">
          <Col title="Company" links={NAV.map((n) => ({ ...n, tid: `footer-nav-${n.id}` }))} />
          <Col title="Printers" links={BRAND_LINKS.map((n) => ({ ...n, tid: `footer-brand-${n.id}` }))} />
          <Col title="Legal" links={[
            { label: "Privacy Policy", to: "/privacy-policy", tid: "footer-link-privacy" },
            { label: "Terms, Refund & Warranty", to: "/terms-and-warranty", tid: "footer-link-terms" },
            { label: "Disclaimer", to: "/disclaimer", tid: "footer-link-disclaimer" },
            { label: "Admin", to: "/admin", tid: "footer-link-admin" },
          ]} />
        </div>
      </div>
      <div className="mt-16 border-t border-[#23415e] pt-8" data-testid="footer-disclaimer-text">
        <p className="text-sm leading-relaxed text-[#d5e2ee]"><strong className="text-[#8fc6ef]">Disclaimer:</strong> {DISCLAIMER_FULL} Printemini is not affiliated with, endorsed by or sponsored by HP Inc., Canon Inc., Seiko Epson Corp. or Brother Industries, Ltd. On-site and workshop repair is available to home and business customers; remote troubleshooting sessions are offered to business customers only.</p>
        {extraDisclaimer && <p className="mt-3 text-xs leading-relaxed text-[#c3d4e4]">{extraDisclaimer}</p>}
        <p className="mt-6 font-mono text-xs text-[#9fb4c8]">© {new Date().getFullYear()} Printemini. All rights reserved.</p>
      </div>
    </div>
  </footer>
);
