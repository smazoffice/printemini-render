import { useRef } from "react";
import { motion, useMotionValue, useSpring, useScroll, useTransform, useMotionTemplate } from "framer-motion";

export const HeroVisual = ({ img, alt, tags = [] }) => {
  const ref = useRef(null);
  const mx = useMotionValue(0.5);
  const my = useMotionValue(0.5);
  const rx = useSpring(useTransform(my, [0, 1], [7, -7]), { stiffness: 120, damping: 18 });
  const ry = useSpring(useTransform(mx, [0, 1], [-9, 9]), { stiffness: 120, damping: 18 });
  const lx = useTransform(mx, (v) => `${v * 100}%`);
  const ly = useTransform(my, (v) => `${v * 100}%`);
  const light = useMotionTemplate`radial-gradient(420px circle at ${lx} ${ly}, rgba(200,230,255,0.28), transparent 60%)`;
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], ["0%", "18%"]);

  const onMove = (e) => {
    const r = ref.current.getBoundingClientRect();
    mx.set((e.clientX - r.left) / r.width);
    my.set((e.clientY - r.top) / r.height);
  };
  const reset = () => { mx.set(0.5); my.set(0.5); };

  return (
    <div ref={ref} onMouseMove={onMove} onMouseLeave={reset} className="relative [perspective:1200px]" data-testid="hero-visual">
      <motion.div style={{ rotateX: rx, rotateY: ry }} className="relative [transform-style:preserve-3d]"
        initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 1.3, ease: [0.16, 1, 0.3, 1], delay: 0.3 }}>
        <div className="clip-frame relative aspect-[4/5] overflow-hidden bg-[#0e2236] sm:aspect-[5/5]">
          <motion.img src={img} alt={alt} style={{ y: imgY, scale: 1.2 }} className="absolute inset-0 h-full w-full object-cover" fetchpriority="high" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_30%_20%,transparent_30%,rgba(14,34,54,0.6)_100%)]" />
          <motion.div className="absolute inset-0 mix-blend-screen" style={{ background: light }} />
        </div>
        {tags.map((t, i) => (
          <div key={t.label} style={{ transform: `translateZ(${60 + i * 30}px)` }}
            className={`absolute ${t.pos} flex items-center gap-2 rounded-full border border-white/20 bg-[#0e2236]/80 px-4 py-2 font-mono text-[11px] uppercase tracking-wider text-[#ffffff] backdrop-blur-md`}>
            <span className="h-1.5 w-1.5 rounded-full bg-[#1f6fb2]" />{t.label}
          </div>
        ))}
      </motion.div>
      <div className="pointer-events-none absolute -bottom-4 -left-4 h-24 w-24 rounded-bl-[32px] border-b-2 border-l-2 border-[#1f6fb2]" />
    </div>
  );
};
