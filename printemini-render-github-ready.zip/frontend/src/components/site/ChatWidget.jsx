import { useState } from "react";
import { useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, Phone, Send, Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { http, formatError } from "../../lib/auth";
import { SITE } from "../../data/site";

const blank = { name: "", contact: "", message: "", company_website: "" };

const ChatPanel = ({ onClose }) => {
  const { pathname } = useLocation();
  const [f, setF] = useState(blank);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await http.post("/chat", { ...f, source_page: pathname });
      setSent(true);
      setF(blank);
    } catch (err) {
      toast.error(formatError(err.response?.data?.detail));
    } finally {
      setBusy(false);
    }
  };

  return (
    <motion.div data-testid="chat-panel" data-lenis-prevent initial={{ opacity: 0, y: 20, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20, scale: 0.96 }} transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
      className="w-[calc(100vw-2.5rem)] max-w-sm origin-bottom-right overflow-hidden rounded-2xl border border-[#23415e] bg-[#0e2236] text-[#ffffff] shadow-2xl">
      <div className="flex items-center justify-between bg-[#1f6fb2] px-5 py-4">
        <a href={SITE.phoneHref} data-testid="chat-phone-link" className="flex items-center gap-2 font-mono text-sm font-semibold text-white"><Phone className="h-4 w-4" />{SITE.phoneDisplay}</a>
        <button onClick={onClose} aria-label="Close chat" data-testid="chat-close-btn"><X className="h-5 w-5 text-white" /></button>
      </div>
      <div className="p-5">
        <p className="font-display text-xl font-black">Send us a quick message</p>
        <p className="mt-1 text-xs text-[#c3d4e4]">We call you back to book your repair.</p>
        {sent ? (
          <p className="mt-6 flex items-center gap-2 text-sm text-emerald-400" data-testid="chat-success-msg"><CheckCircle2 className="h-4 w-4" />Message sent. We'll get back to you shortly.</p>
        ) : (
          <form onSubmit={submit} className="mt-4 space-y-3">
            <input required minLength={2} className="field" placeholder="Your name" value={f.name} onChange={set("name")} data-testid="chat-input-name" />
            <input required type="tel" minLength={7} className="field" placeholder="Your phone number" value={f.contact} onChange={set("contact")} data-testid="chat-input-phone" />
            <textarea required minLength={3} rows={3} className="field resize-none" placeholder="How can we help? e.g. printer model and issue" value={f.message} onChange={set("message")} data-testid="chat-input-message" />
            <input tabIndex={-1} autoComplete="off" className="hidden" value={f.company_website} onChange={set("company_website")} aria-hidden="true" />
            <button disabled={busy} data-testid="chat-send-btn" className="flex w-full items-center justify-center gap-2 rounded-full bg-[#1f6fb2] py-3 text-sm font-semibold text-white transition-colors hover:bg-[#175a93] disabled:opacity-60">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}Send message
            </button>
          </form>
        )}
      </div>
    </motion.div>
  );
};

export const ChatWidget = () => {
  const [open, setOpen] = useState(false);
  return (
    <div className="fixed bottom-20 right-5 z-50 flex flex-col items-end gap-3 md:bottom-6">
      <AnimatePresence>{open && <ChatPanel onClose={() => setOpen(false)} />}</AnimatePresence>
      <motion.button whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.94 }} onClick={() => setOpen(!open)} aria-label="Open quick chat" data-testid="chat-toggle-btn"
        className="flex h-14 w-14 items-center justify-center rounded-full bg-[#0e2236] text-white shadow-xl ring-2 ring-[#1f6fb2]">
        {open ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </motion.button>
    </div>
  );
};
