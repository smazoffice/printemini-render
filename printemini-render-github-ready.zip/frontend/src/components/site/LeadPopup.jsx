import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { toast } from "sonner";
import { Loader2, CheckCircle2, Phone } from "lucide-react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "../ui/dialog";
import { http, formatError } from "../../lib/auth";
import { SITE } from "../../data/site";

const KEY = "pm_popup_done";
const blank = { customer_type: "home", company: "", email: "", phone: "", brand: "HP" };

export const LeadPopup = () => {
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState(blank);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  useEffect(() => {
    if (localStorage.getItem(KEY)) return undefined;
    const t = setTimeout(() => setOpen(true), 1800);
    return () => clearTimeout(t);
  }, []);

  const close = (v) => { setOpen(v); if (!v) localStorage.setItem(KEY, "1"); };

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await http.post("/leads", { ...f, issue_category: "Quick enquiry (popup)", visit_type: "on-site", source_page: `${pathname} popup` });
      setDone(true);
      localStorage.setItem(KEY, "1");
    } catch (err) {
      toast.error(formatError(err.response?.data?.detail));
    } finally {
      setBusy(false);
    }
  };

  const input = "w-full rounded-xl border border-[#d6e6f3] bg-[#f6fafe] px-4 py-3 text-sm text-[#0e2236] outline-none transition-colors focus:border-[#1f6fb2]";

  return (
    <Dialog open={open} onOpenChange={close}>
      <DialogContent data-testid="lead-popup" data-lenis-prevent className="max-w-md overflow-hidden rounded-3xl border-[#d6e6f3] bg-[#ffffff] p-0">
        <div className="relative bg-[#0e2236] px-7 pb-6 pt-7 text-[#f4f8fc]">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_80%_at_90%_0%,rgba(75,163,227,0.35),transparent_70%)]" />
          <p className="relative font-mono text-[11px] uppercase tracking-[0.2em] text-[#8fc6ef]">Quick call-back</p>
          <DialogTitle className="relative mt-2 font-display text-3xl text-[#f4f8fc]">Printer giving you trouble?</DialogTitle>
          <DialogDescription className="relative mt-2 text-sm text-[#c3d4e4]">Leave your details and a technician will call you back to book a repair at home or at work.</DialogDescription>
        </div>
        {done ? (
          <div className="px-7 py-8" data-testid="lead-popup-success">
            <p className="flex items-center gap-2 font-semibold text-[#0e2236]"><CheckCircle2 className="h-5 w-5 text-[#1f6fb2]" />Thank you, we'll call you shortly.</p>
            <a href={SITE.phoneHref} className="mt-4 inline-flex items-center gap-2 font-mono text-sm text-[#175a93]"><Phone className="h-4 w-4" />{SITE.phoneDisplay}</a>
          </div>
        ) : (
          <form onSubmit={submit} className="space-y-3 px-7 py-6">
            <select className={input} value={f.customer_type} onChange={set("customer_type")} data-testid="popup-select-customer-type"><option value="home">Home / personal</option><option value="business">Business / office</option></select>
            {f.customer_type === "business" && <input className={input} placeholder="Company name" value={f.company} onChange={set("company")} data-testid="popup-input-company" />}
            <input required type="email" className={input} placeholder="Email" value={f.email} onChange={set("email")} data-testid="popup-input-email" />
            <input required type="tel" minLength={7} className={input} placeholder="Phone number" value={f.phone} onChange={set("phone")} data-testid="popup-input-phone" />
            <select className={input} value={f.brand} onChange={set("brand")} data-testid="popup-select-brand">
              {["HP", "Canon", "Epson", "Brother", "Other"].map((b) => <option key={b}>{b}</option>)}
            </select>
            <button disabled={busy} data-testid="popup-submit-btn" className="flex w-full items-center justify-center gap-2 rounded-full bg-[#0e2236] py-3.5 text-sm font-semibold text-[#f4f8fc] transition-colors hover:bg-[#1f6fb2] disabled:opacity-60">
              {busy && <Loader2 className="h-4 w-4 animate-spin" />}Request a call back
            </button>
            <button type="button" onClick={() => close(false)} className="w-full text-center text-xs text-[#46586b] underline-offset-2 hover:underline" data-testid="popup-dismiss-btn">No thanks</button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
};
