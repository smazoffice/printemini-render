import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Wrench, MonitorSmartphone, Building2 } from "lucide-react";
import { Reveal, SectionLabel } from "./Motion";

const PROBLEMS = [
  { id: "jams", label: "Paper keeps jamming", fix: "Pickup, feed and separation roller replacement plus a full paper-path clean.", service: "On-site visit or workshop drop-off", fee: "Visit $89 · workshop diagnostic $49", Icon: Wrench },
  { id: "quality", label: "Streaks, smudges or faded prints", fix: "Fuser test and replacement on laser models; printhead cleaning or replacement on inkjets.", service: "On-site visit or workshop drop-off", fee: "Visit $89 · workshop diagnostic $49", Icon: Wrench },
  { id: "noise", label: "Grinding or clicking noises", fix: "Gear, carriage and roller inspection with worn parts replaced before they break.", service: "On-site visit", fee: "Visit $89", Icon: Wrench },
  { id: "wifi", label: "Printer offline or not on Wi-Fi", fix: "Home: technician visit to reconnect and lock in a fixed IP. Business: a booked remote session with your staff.", service: "On-site visit · remote session for business", fee: "Visit $89 · remote $59 / 30 min", Icon: MonitorSmartphone },
  { id: "ink", label: "Ink pads or maintenance box full", fix: "Physical replacement of waste ink pads or maintenance box, then nozzle check and test print.", service: "Workshop drop-off", fee: "Workshop diagnostic $49", Icon: Wrench },
  { id: "fleet", label: "Several office printers to look after", fix: "Scheduled preventive maintenance, wear-part checks and a report for every device.", service: "Office maintenance plan", fee: "From $129 per device / visit", Icon: Building2 },
];

const Result = ({ p }) => (
  <motion.div key={p.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}
    className="rounded-3xl border border-[#cfe3f5] bg-white p-7 shadow-[0_30px_60px_-30px_rgba(31,111,178,0.35)] sm:p-9" data-testid="problem-finder-result">
    <p.Icon className="h-7 w-7 text-[#1f6fb2]" />
    <p className="mt-5 font-mono text-xs uppercase tracking-[0.2em] text-[#46586b]">Recommended</p>
    <h3 className="mt-2 font-display text-2xl sm:text-3xl">{p.service}</h3>
    <p className="mt-4 text-base leading-relaxed text-[#46586b]">{p.fix}</p>
    <p className="mt-5 inline-block rounded-full bg-[#eef6fd] px-4 py-2 font-mono text-xs text-[#175a93]">{p.fee}</p>
    <button onClick={() => window.__lenis?.scrollTo("#contact", { offset: -90 })} data-testid="problem-finder-book-btn"
      className="group mt-8 flex items-center gap-2 rounded-full bg-[#1f6fb2] px-6 py-3.5 text-sm font-semibold text-white transition-colors hover:bg-[#175a93]">
      Book this repair<ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
    </button>
  </motion.div>
);

export const ProblemFinder = ({ brand }) => {
  const [sel, setSel] = useState(PROBLEMS[0]);
  return (
    <section className="mx-auto grid max-w-[1400px] gap-10 px-5 py-24 sm:px-8 sm:py-28 lg:grid-cols-12" data-testid="problem-finder-section">
      <Reveal className="lg:col-span-6">
        <SectionLabel n="00">Problem finder</SectionLabel>
        <h2 className="font-display text-4xl leading-[1.05] tracking-tight sm:text-5xl">What is your {brand ? `${brand} ` : ""}printer doing?</h2>
        <p className="mt-5 max-w-xl text-base leading-relaxed text-[#46586b]">Pick the closest symptom to see how we fix it, which service fits and what it costs to start.</p>
        <div className="mt-8 flex flex-wrap gap-2.5">
          {PROBLEMS.map((p) => (
            <button key={p.id} onClick={() => setSel(p)} data-testid={`problem-chip-${p.id}`}
              className={`rounded-full border px-4 py-2.5 text-sm font-medium transition-[background-color,color,border-color] duration-200 ${sel.id === p.id ? "border-[#1f6fb2] bg-[#1f6fb2] text-white" : "border-[#cfe3f5] bg-white text-[#0e2236] hover:border-[#1f6fb2]"}`}>
              {p.label}
            </button>
          ))}
        </div>
      </Reveal>
      <div className="lg:col-span-6"><Result p={sel} /></div>
    </section>
  );
};
