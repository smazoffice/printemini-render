import { motion } from "framer-motion";

const EASE = [0.16, 1, 0.3, 1];

export const Reveal = ({ children, delay = 0, className = "", y = 28 }) => (
  <motion.div
    className={className}
    initial={{ opacity: 0, y }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, amount: 0.12 }}
    transition={{ duration: 0.9, ease: EASE, delay }}
  >
    {children}
  </motion.div>
);

export const MaskedHeadline = ({ lines, accent = -1, testId, className = "" }) => (
  <h1 data-testid={testId} className={`font-display font-extrabold leading-[1.02] tracking-[-0.04em] ${className}`}>
    {lines.map((line, i) => (
      <span key={line} className="block overflow-hidden pb-[0.08em]">
        <motion.span
          className={`block ${i === accent ? "text-[#1f6fb2]" : ""}`}
          initial={{ y: "105%" }}
          animate={{ y: 0 }}
          transition={{ duration: 1.1, ease: EASE, delay: 0.15 + i * 0.13 }}
        >
          {line}
        </motion.span>
      </span>
    ))}
  </h1>
);

export const SectionLabel = ({ n, children, dark = false }) => (
  <p className={`mb-5 flex items-center gap-3 font-mono text-xs font-semibold uppercase tracking-[0.22em] ${dark ? "text-[#c3d4e4]" : "text-[#46586b]"}`}>
    <span className="text-[#1f6fb2]">{n}</span><span className={`h-px w-10 ${dark ? "bg-[#34587a]" : "bg-[#d6e6f3]"}`} />{children}
  </p>
);
