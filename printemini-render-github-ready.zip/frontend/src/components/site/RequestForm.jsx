import { useState } from "react";
import { useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { ArrowRight, Loader2, Phone, CheckCircle2 } from "lucide-react";
import { http, formatError } from "../../lib/auth";
import { Reveal, SectionLabel } from "./Motion";
import { SITE } from "../../data/site";

const ISSUES = ["Driver or print queue problem", "Network / Wi-Fi printing", "Scan-to-email or folder setup", "Paper jams / feeding", "Print quality (streaks, smudges)", "Fuser or printhead fault", "Noise or mechanical fault", "Preventive maintenance", "Other"];
const BRANDS = ["HP", "Canon", "Epson", "Brother", "Other"];

const Field = ({ label, children }) => (
  <label className="block"><span className="font-mono text-[11px] uppercase tracking-[0.18em] text-[#c3d4e4]">{label}</span>{children}</label>
);

export const RequestForm = ({ brand = "HP" }) => {
  const { pathname } = useLocation();
  const blank = { customer_type: "home", company: "", name: "", phone: "", email: "", brand, model: "", issue_category: ISSUES[0], location: "", visit_type: "on-site", preferred_time: "", description: "", company_website: "" };
  const [f, setF] = useState(blank);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const setType = (e) => setF({ ...f, customer_type: e.target.value, visit_type: e.target.value === "home" && f.visit_type === "remote" ? "on-site" : f.visit_type });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await http.post("/leads", { ...f, email: f.email || null, source_page: pathname });
      setDone(true);
      setF(blank);
      toast.success("Request received. We'll call you to book your repair.");
    } catch (err) {
      toast.error(formatError(err.response?.data?.detail));
    } finally {
      setBusy(false);
    }
  };

  return (
    <section id="contact" className="relative overflow-hidden bg-[#0e2236] text-[#ffffff]" data-testid="contact-section">
      <div className="grain pointer-events-none absolute inset-0" />
      <div className="relative mx-auto grid max-w-[1400px] gap-14 px-5 py-24 sm:px-8 sm:py-32 lg:grid-cols-12">
        <Reveal className="lg:col-span-5">
          <SectionLabel n="07" dark>Book a repair</SectionLabel>
          <h2 className="font-display text-4xl font-black leading-[1] tracking-tight sm:text-5xl">Tell us what it's doing. <span className="text-[#8fc6ef]">We'll fix it properly.</span></h2>
          <p className="mt-6 text-base leading-relaxed text-[#c3d4e4]">For homes and businesses. Book an on-site repair or a workshop drop-off; business customers can also book a remote troubleshooting session. We call you back to confirm the time.</p>
          <a href={SITE.phoneHref} data-testid="contact-call-btn" className="mt-8 inline-flex items-center gap-3 rounded-full border border-[#34587a] px-6 py-3.5 font-mono text-sm transition-colors hover:border-[#1f6fb2] hover:text-[#1f6fb2]"><Phone className="h-4 w-4" />{SITE.phoneDisplay}</a>
          <a href={`mailto:${SITE.email}`} data-testid="contact-email-link" className="mt-4 block font-mono text-sm text-[#c3d4e4] hover:text-[#1f6fb2]">{SITE.email}</a>
          <p className="mt-2 text-sm text-[#c3d4e4]" data-testid="contact-address">{SITE.address}</p>
          <p className="mt-8 max-w-md text-xs leading-relaxed text-[#9fb4c8]">By sending this form you agree we may contact you about this repair. See our Privacy Policy.</p>
        </Reveal>
        <motion.form onSubmit={submit} data-testid="hero-request-form" className="grid gap-7 rounded-3xl border border-[#23415e] bg-[#14304a]/60 p-6 backdrop-blur sm:grid-cols-2 sm:p-10 lg:col-span-7"
          initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.1 }} transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}>
          {done && <p className="flex items-center gap-2 text-sm text-emerald-400 sm:col-span-2" data-testid="form-success-msg"><CheckCircle2 className="h-4 w-4" />Thanks — your request is in. We'll call you shortly.</p>}
          <Field label="Customer type *"><select className="field" value={f.customer_type} onChange={setType} data-testid="select-customer-type"><option value="home">Home / personal</option><option value="business">Business / office</option></select></Field>
          <Field label="Company (if business)"><input className="field" value={f.company} onChange={set("company")} placeholder="Acme Dental LLC" data-testid="input-company-name" /></Field>
          <Field label="Your name *"><input required minLength={2} className="field" value={f.name} onChange={set("name")} placeholder="Jane Smith" data-testid="input-customer-name" /></Field>
          <Field label="Phone *"><input required type="tel" minLength={7} className="field" value={f.phone} onChange={set("phone")} placeholder="(804) 555-0100" data-testid="input-customer-phone" /></Field>
          <Field label="Email"><input type="email" className="field" value={f.email} onChange={set("email")} placeholder="optional" data-testid="input-customer-email" /></Field>
          <Field label="Printer brand *"><select className="field" value={f.brand} onChange={set("brand")} data-testid="select-printer-brand">{BRANDS.map((b) => <option key={b}>{b}</option>)}</select></Field>
          <Field label="Printer model"><input className="field" value={f.model} onChange={set("model")} placeholder="e.g. LaserJet Pro M404" data-testid="input-printer-model" /></Field>
          <Field label="Issue type *"><select className="field" value={f.issue_category} onChange={set("issue_category")} data-testid="select-issue-category">{ISSUES.map((i) => <option key={i}>{i}</option>)}</select></Field>
          <Field label="ZIP code or address"><input className="field" value={f.location} onChange={set("location")} placeholder="Where is the printer?" data-testid="input-service-address" /></Field>
          <Field label="Service type *"><select className="field" value={f.visit_type} onChange={set("visit_type")} data-testid="select-visit-type"><option value="on-site">On-site repair visit</option><option value="drop-off">Workshop drop-off</option>{f.customer_type === "business" && <option value="remote">Remote troubleshooting session</option>}</select></Field>
          <Field label="Preferred date & time"><input className="field" value={f.preferred_time} onChange={set("preferred_time")} placeholder="e.g. Tue morning" data-testid="input-preferred-time" /></Field>
          <div className="sm:col-span-2"><Field label="Describe the issue"><textarea rows={3} className="field resize-none" value={f.description} onChange={set("description")} placeholder="What happens, any error code on the display, how long it's been going on" data-testid="input-issue-description" /></Field></div>
          <input tabIndex={-1} autoComplete="off" className="hidden" value={f.company_website} onChange={set("company_website")} aria-hidden="true" />
          <button disabled={busy} type="submit" data-testid="submit-service-request-btn" className="group flex items-center justify-center gap-3 rounded-full bg-[#1f6fb2] px-8 py-4 font-semibold text-white transition-[transform,background-color] duration-200 hover:-translate-y-0.5 hover:bg-[#175a93] active:scale-[0.98] disabled:opacity-60 sm:col-span-2 sm:justify-self-start">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}Send request<ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </button>
        </motion.form>
      </div>
    </section>
  );
};
