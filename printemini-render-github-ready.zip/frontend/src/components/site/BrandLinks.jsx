import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { Reveal, SectionLabel } from "./Motion";
import { BRANDS } from "../../data/brands";

export const BrandLinks = ({ exclude, n = "01" }) => {
  const list = Object.entries(BRANDS).filter(([k]) => k !== exclude);
  return (
    <section className="mx-auto max-w-[1400px] px-5 py-24 sm:px-8 sm:py-28" data-testid="brand-links-section">
      <Reveal className="mb-12 grid gap-6 lg:grid-cols-12 lg:items-end">
        <div className="lg:col-span-7">
          <SectionLabel n={n}>Printers we repair</SectionLabel>
          <h2 className="font-display text-4xl font-black leading-[1] tracking-tight sm:text-5xl">{exclude ? "We also repair" : "Brands on our bench every week."}</h2>
        </div>
        <p className="text-sm leading-relaxed text-[#46586b] lg:col-span-5">Laser and inkjet printers from the brands homes and offices use most, repaired on site or on our workshop bench.</p>
      </Reveal>
      <div className={`grid gap-px border border-[#d6e6f3] bg-[#d6e6f3] ${list.length === 4 ? "md:grid-cols-2 lg:grid-cols-4" : "md:grid-cols-3"}`}>
        {list.map(([k, b], i) => (
          <Reveal key={k} delay={i * 0.08}>
            <Link to={`/${b.slug}`} data-testid={`brand-link-${k}`} className="group relative flex h-full min-h-[280px] flex-col justify-between overflow-hidden bg-[#ffffff] p-8 transition-colors duration-500 hover:bg-[#0e2236] hover:text-[#ffffff]">
              <div className="flex items-start justify-between">
                <span className="font-mono text-xs uppercase tracking-[0.2em] text-[#175a93] group-hover:text-[#b9dcf5]">Repair specialists</span>
                <ArrowUpRight className="h-6 w-6 transition-transform duration-300 group-hover:-translate-y-1 group-hover:translate-x-1" />
              </div>
              <div>
                <p className="font-display text-6xl font-black tracking-tight sm:text-7xl">{b.key}</p>
                <p className="mt-3 text-sm text-[#46586b] group-hover:text-[#c3d4e4]">{b.models.slice(0, 4).join(" · ")}</p>
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </section>
  );
};
