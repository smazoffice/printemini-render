import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Phone, ArrowRight } from "lucide-react";
import { MaskedHeadline } from "./Motion";
import { HeroVisual } from "./HeroVisual";
import { SITE } from "../../data/site";

const PILLS = ["Home & business", "On-site repair", "Remote sessions for offices", "Quote before work"];

export const Hero = ({ eyebrow, lines, accent, sub, img, alt, tags }) => (
  <section className="relative overflow-hidden bg-[#eef6fd] text-[#0e2236]" data-testid="hero-section">
    <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(55%_60%_at_80%_20%,rgba(75,163,227,0.28)_0%,transparent_70%),radial-gradient(40%_40%_at_10%_90%,rgba(75,163,227,0.14)_0%,transparent_70%)]" />
    <div className="grain pointer-events-none absolute inset-0" />
    <div className="relative mx-auto grid max-w-[1400px] gap-12 px-5 pb-20 pt-12 sm:px-8 sm:pt-16 lg:grid-cols-12 lg:gap-10 lg:pb-28">
      <div className="lg:col-span-7 lg:pt-6">
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8 }} className="mb-8 inline-flex items-center gap-2 rounded-full border border-[#cfe3f5] bg-white/70 px-3 py-1.5 font-mono text-[11px] font-semibold uppercase tracking-[0.2em] text-[#34587a] backdrop-blur" data-testid="hero-eyebrow">
          <span className="h-1.5 w-1.5 rounded-full bg-[#1f6fb2]" />{eyebrow}
        </motion.p>
        <MaskedHeadline lines={lines} accent={accent} testId="hero-headline" className="text-[11vw] sm:text-7xl lg:text-[5.6rem] xl:text-[6.4rem]" />
        <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.6 }} data-testid="hero-subheadline" className="mt-8 max-w-xl text-base leading-relaxed text-[#46586b] md:text-lg">{sub}</motion.p>
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.75 }} className="mt-10 flex flex-wrap items-center gap-4">
          <Link to="#contact" onClick={(e) => { e.preventDefault(); window.__lenis?.scrollTo("#contact", { offset: -90 }); }} data-testid="hero-request-btn" className="group inline-flex items-center gap-3 rounded-full bg-[#1f6fb2] px-7 py-4 font-semibold text-white shadow-[0_10px_40px_-10px_rgba(31,111,178,0.6)] transition-[transform,background-color] duration-200 hover:-translate-y-0.5 hover:bg-[#175a93] active:scale-[0.98]">Book a repair<ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" /></Link>
          <a href={SITE.phoneHref} data-testid="hero-call-btn" className="inline-flex items-center gap-3 rounded-full border border-[#b8d4ee] bg-white/60 px-7 py-4 font-mono text-sm font-semibold text-[#0e2236] transition-colors hover:border-[#1f6fb2] hover:bg-white"><Phone className="h-4 w-4" />{SITE.phoneDisplay}</a>
        </motion.div>
        <motion.ul initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, delay: 0.95 }} className="mt-10 flex flex-wrap gap-x-6 gap-y-2">
          {PILLS.map((p) => <li key={p} className="flex items-center gap-2 text-sm text-[#46586b]"><span className="h-px w-4 bg-[#1f6fb2]" />{p}</li>)}
        </motion.ul>
      </div>
      <div className="lg:col-span-5"><HeroVisual img={img} alt={alt} tags={tags} /></div>
    </div>
  </section>
);
