import { ChatWidget } from "./ChatWidget";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { MobileCallBar } from "./MobileCallBar";
import { LeadPopup } from "./LeadPopup";

export const Layout = ({ children, extraDisclaimer }) => (
  <div className="min-h-screen bg-[#ffffff]">
    <Header />
    <main>{children}</main>
    <Footer extraDisclaimer={extraDisclaimer} />
    <MobileCallBar />
    <ChatWidget />
    <LeadPopup />
  </div>
);
