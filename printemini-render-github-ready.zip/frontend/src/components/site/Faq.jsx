import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "../ui/accordion";
import { Reveal, SectionLabel } from "./Motion";

export const Faq = ({ items, n = "08" }) => (
  <section className="mx-auto grid max-w-[1400px] gap-12 px-5 py-24 sm:px-8 sm:py-32 lg:grid-cols-12" data-testid="faq-section">
    <Reveal className="lg:col-span-4">
      <SectionLabel n={n}>Questions</SectionLabel>
      <h2 className="font-display text-4xl font-black leading-[1] tracking-tight sm:text-5xl">Straight answers.</h2>
    </Reveal>
    <Accordion type="single" collapsible className="lg:col-span-8">
      {items.map((it, i) => (
        <AccordionItem key={it.q} value={`q${i}`} className="border-[#d6e6f3]">
          <AccordionTrigger data-testid={`faq-trigger-${i}`} className="py-6 text-left font-display text-lg font-bold hover:no-underline sm:text-xl">{it.q}</AccordionTrigger>
          <AccordionContent className="pb-6 text-base leading-relaxed text-[#46586b]">{it.a}</AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  </section>
);
