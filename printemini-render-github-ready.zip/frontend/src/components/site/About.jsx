import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Reveal, SectionLabel } from "./Motion";

const POINTS = [
  ["Independent", "We are our own business, not a manufacturer's service centre or reseller."],
  ["Home & business", "On-site and workshop repair for everyone; remote sessions for business customers."],
  ["Quote first", "A written price before parts are ordered or work begins."],
  ["Warranty", "Repairs are covered by our parts and labour warranty."],
];

export const About = () => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["-8%", "8%"]);
  return (
    <section id="about" ref={ref} className="mx-auto grid max-w-[1400px] gap-12 px-5 py-24 sm:px-8 sm:py-32 lg:grid-cols-12" data-testid="about-section">
      <div className="relative lg:col-span-5">
        <div className="relative aspect-[4/5] overflow-hidden rounded-[28px] [clip-path:inset(0_0_0_0_round_28px)]">
          <motion.img style={{ y, scale: 1.15 }} src="/images/homeprint.jpg" alt="Printing documents on a home office printer after a Printemini repair" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
        </div>
        <p className="mt-3 font-mono text-xs text-[#46586b]">Printing again, at home or at work</p>
      </div>
      <div className="lg:col-span-7 lg:pl-8">
        <Reveal>
          <SectionLabel n="06">About us</SectionLabel>
          <h2 className="font-display text-4xl font-black leading-[1] tracking-tight sm:text-5xl">Printer people with <span className="text-[#1f6fb2]">screwdrivers</span>, not scripts.</h2>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-[#46586b]">Printemini is an independent printer service business working with homes, home offices and businesses. We repair laser and inkjet hardware on site or in our workshop, troubleshoot office printers remotely in booked sessions for business customers, set up printers on local networks, and look after small office fleets with scheduled maintenance. We are not affiliated with any printer manufacturer; we simply know their machines well.</p>
        </Reveal>
        <div className="mt-12 grid gap-px border border-[#d6e6f3] bg-[#d6e6f3] sm:grid-cols-2">
          {POINTS.map(([t, d], i) => (
            <Reveal key={t} delay={i * 0.06} className="bg-[#ffffff] p-6">
              <h3 className="font-display text-xl font-bold">{t}</h3>
              <p className="mt-2 text-sm leading-relaxed text-[#46586b]">{d}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
};
