# Printemini: GitHub + Render deployment

## 1. GitHub
Create a **private** repository named `printemini-render`. Unzip this archive locally. Upload its **contents** to the repository root (not the ZIP itself). Do not upload any `.env` file, password, or credentials.

## 2. Database
Create or use a MongoDB Atlas cluster and database. Obtain a fresh MongoDB connection URI, set Atlas network access appropriately, and use a least-privilege database user. The Emergent development database URI may not work outside Emergent.

## 3. Render
Open https://dashboard.render.com/blueprints and create a Blueprint from the GitHub repository's `render.yaml`. Review the proposed resources and charges before approving. The configuration requests a free web service and a static site; availability and pricing depend on Render's current plans.

Set these backend values during Blueprint approval:
- `MONGO_URL`: MongoDB Atlas connection URI (keep secret)
- `DB_NAME`: your database name
- `ADMIN_EMAIL`: your admin login email
- `ADMIN_PASSWORD`: a NEW strong admin password (do not reuse an old password)
- `CORS_ORIGINS`: your Render frontend URL, e.g. `https://printemini-site.onrender.com` (adjust to actual assigned URL); add `https://printemini.com,https://www.printemini.com` when domains are connected
- `OWNER_EMAIL`, `CHAT_EMAIL`: destination addresses for website notifications
- `EMAIL_FROM_NAME`: desired sender name
- `EMERGENT_EMAIL_KEY`: only if the Emergent email service remains usable outside Emergent; otherwise replace the email integration before relying on notifications

Set the frontend `REACT_APP_BACKEND_URL` to the backend's actual `https://...onrender.com` URL, with no trailing `/api`. This is a **build-time** variable; redeploy the frontend after changing it.

## 4. Test before domain changes
Visit backend `/api/` and frontend `/`; test login, lead form, notifications, and deep links (`/admin`, `/guides`). If login uses cookies, verify cross-origin cookie behavior with the deployed domains.

## 5. Custom domain
Only after successful tests, add `printemini.com` and optionally `www.printemini.com` in the Render static site's Custom Domains page. Apply the exact DNS records Render shows at your DNS provider. Do not change MX/email records. Wait for HTTPS verification.

## Caveats
- Backend requirements contain an Emergent-hosted Python wheel URL; this may not be publicly accessible from Render. Resolve this dependency if build fails.
- Email integration uses an Emergent email endpoint and may require replacement.
- No live build, database connection, or end-to-end testing has been performed in this preparation step.
- If the archive contained live secrets, rotate them before deployment, even though they are excluded from this package.
